'''
作用:配置文件
configs:
- 1.debug : 调试模式 :True  生产:False
- 2.template_path : 模板路径
- 3.static_path : 静态路径
'''
import os
# from pprint import pprint   格式化输出

root_path = os.path.dirname(__file__)


configs = dict(
    debug = True,
    template_path = os.path.join(root_path,'templates'),
    static_path = os.path.join(root_path,'statics')
)