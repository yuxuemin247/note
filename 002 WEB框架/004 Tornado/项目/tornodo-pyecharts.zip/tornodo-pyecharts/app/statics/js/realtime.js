/*
realtime.js
作用:ws协议的客户端,负责和后端建立通讯
*/

//全局连接对象
var conn = null;

//定义连接函数
function connect(){
    //定义协议
    var transports = ["websocket"];
    //创建连接对象
    conn = new SockJS("http://"+window.location.host+"/real/time",transports);
    //正在连接
    console.log("正在连接....");

    //建立连接的回调函数
    conn.onopen = function(){
        console.log("连接成功!");
    }

    //建立接受消息的回调函数
    conn.onmessage = function(e){
        //e时json类型,js中叫object对象类型
        var data = e.data;
        //将json字符串转换为object对象类型
        data = JSON.parse(data);

        china_total(data.china_total);

        china_map(data.china_map);
    }

    //需要不停的告诉ws服务器,当前浏览器连接没有断开
    setInterval(function(){
        conn.send('test');
    },5000)
}

//定义断开的函数
function disconnect(){
    if(conn!=null){
        conn.close();//关闭连接
        conn = null;
        console.log('断开连接...')
    }
}

//页面一刷新断开
if(conn == null){
    connect()
}else{
    disconnect()
}