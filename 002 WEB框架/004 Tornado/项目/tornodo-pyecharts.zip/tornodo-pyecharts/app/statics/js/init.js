/*
init.js
作用 : 完成页面初始化的
*/

var nowConfirms = true;
var heals = false;
var deads = false;

//当页面加载完成时
$(document).ready(function(){
    data = chart_chinaMap._chartsMap
    for(var i in data){
        //循环和python不一样 i 是key
        label = data[i].__id.substring(5,9);
        value = data[i].__alive;

        if(label=='现有确诊'){
            nowConfirms = value;
        }else if(label=='累计治愈'){
            heals = value;
        }else if(label == '累计死亡'){
            deads = value;
        }
    }
    console.log('js初始化加载')
});
