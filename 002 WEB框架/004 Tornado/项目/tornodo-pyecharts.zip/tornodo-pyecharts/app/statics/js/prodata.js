/*
prodata.js
作用:处理socket返回的数据的,把数据实时替换到原有的html中

备注，所有的函数调用都在realtime.js中的on_message()中(当接受到新的消息时才会被触发)
*/


//处理累计确诊 和 现有确诊
function china_total(data){
    $("#confirm").text(data.confirm);
    $("#nowConfirm").text(data.nowConfirm);
}

//处理地图的跟新
function china_map(data){


//    //显示标签状态码 bool值
//    var con = option_chinaMap.legend[0].selected['现有确诊'];
//    var heal = option_chinaMap.legend[0].selected['累计治愈'];
//    var dead = option_chinaMap.legend[0].selected['累计死亡'];

    //console.log(data)
    option_chinaMap.series[0].data = data.nowConfirms;
    option_chinaMap.series[1].data = data.heals;
    option_chinaMap.series[2].data = data.deads;

//    console.log('c',nowConfirms);
//    console.log('h',heals);
//    console.log('d',deads);

    //更新状态码  //不点击的时候也会刷新
    option_chinaMap.legend[0].selected['现有确诊'] = nowConfirms;
    option_chinaMap.legend[0].selected['累计治愈'] = heals;
    option_chinaMap.legend[0].selected['累计死亡'] = deads;

    //将js的数据打印到html中
    chart_chinaMap.setOption(option_chinaMap);
}

$("#china_map").click(function(){
    data = chart_chinaMap._chartsMap
    for(var i in data){
        //循环和python不一样 i 是key
        label = data[i].__id.substring(5,9);
        value = data[i].__alive;
        console.log(label,value)
        if(label=='现有确诊'){
            nowConfirms = value;
        }else if(label=='累计治愈'){
            heals = value;
        }else if(label == '累计死亡'){
            deads = value;
        }
    }

});