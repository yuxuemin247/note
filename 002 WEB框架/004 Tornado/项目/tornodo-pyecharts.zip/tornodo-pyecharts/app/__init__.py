'''
web框架部分
http服务
option 配置项
ioloop 监听
define 定义端口
'''
from tornado import web,httpserver,ioloop
from tornado.options import options,define
from app.configs import configs
from app.urls import urls
#定义端口
define('port',default=8000,type=int,help='run')

#自定义应用
class CustomApplication(web.Application):
    #重写
    def __init__(self):
        #指定路由的规则
        handlers = urls
        #指定配置信息
        settings = configs
        #调用父类的__init__,传入两个参数
        super(CustomApplication,self).__init__(handlers=handlers,**settings)

#自定义的服务
def create_server():
    #允许再命令行启动
    options.parse_command_line()
    #创建http服务
    http_server = httpserver.HTTPServer(
        CustomApplication()
    )
    #绑定监听接口
    http_server.listen(options.port)
    #启动输入输出事件循环
    ioloop.IOLoop.instance().start()