'''
urls.py
作用:路由定义
sockjs:帮助框架升级http协议，ws->websocket
http1.0  短链接  比较浪费效率,一个请求 3次握手  4次挥手
http1.1  长连接  添加了max-age(最大连接生命周期)  一次3次握手  等你不使用了  4次挥手
ws ： 连接以后,服务器可以给客户端发送消息(最好不添加最大生命周期)
'''
from sockjs.tornado import SockJSRouter #ws协议路由
from app.views.view_index import IndexHandler as index
from app.views.view_real_time import RealTimeHandler as real_time
#路由 r b f u
urls = [
    (r'/',index),
] + SockJSRouter(real_time,"/real/time").urls

