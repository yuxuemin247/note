'''
getdata.py
作用 ：使用pandas再数据库当中获取想要的数据
逻辑 : 如果有今天数据则获取今天的数据，如果没有则获取昨天的数据
'''
import pandas as pd
from datetime import date,timedelta
import warnings
from sqlalchemy import create_engine
warnings.filterwarnings('ignore')

class GetData(object):
    conn = create_engine('mysql+pymysql://root:123456@localhost:3306/nz1904')

    def get_total(self):
        today = date.today()  # 2020-03-16
        sql = f"select `confirm`,`nowConfirm` from `chinaTotal` where date(`create_dt`)='{today}'"
        data = pd.read_sql(sql, self.conn)

        # 如果今天的数据不存在,那么获取昨天更新的数据
        if data.shape[0] == 0:
            # 计算的昨天的日期
            yesterday = (date.today() + timedelta(days=-1)).strftime("%Y-%m-%d")
            sql = f"select `confirm`,`nowConfirm` from `chinaTotal` where date(`create_dt`)='{yesterday}'"
            data = pd.read_sql(sql, self.conn)
        return data

    def get_province(self):
        '''
        获取中国今天的综合数据
        table : province
        :return: DataFrame
        '''

        today = date.today() #2020-03-16
        sql = f"select `province_name`,`total_confirm`,`heal`,`dead` from `province` where date(`create_dt`)='{today}'"
        data = pd.read_sql(sql,self.conn)

        #如果今天的数据不存在,那么获取昨天更新的数据
        if data.shape[0] == 0:
            #计算的昨天的日期
            yesterday = (date.today() + timedelta(days=-1)).strftime("%Y-%m-%d")
            sql = f"select `province_name`,`total_confirm`,`heal`,`dead` from `province` where date(`create_dt`)='{yesterday}'"
            data = pd.read_sql(sql, self.conn)
        return data

    def get_line(self):
        '''
        获取的是时间轴中的 现有确诊,累计死亡和累计自愈
        :return: DataFrame
        '''

        sql = f"select `nowConfirm`,`heal`,`dead`,date(`create_dt`) as `createdt`  from `chinaTotal`"
        data = pd.read_sql(sql, self.conn)
        return data