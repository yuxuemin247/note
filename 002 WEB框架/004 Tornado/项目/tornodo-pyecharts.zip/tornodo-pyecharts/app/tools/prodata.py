'''
prodata.py

作用 ： 处理实时返回的中国地图数据的,处理成list包裹字典
'''
class ProData(object):

    def pro_province(self, province_data):
        '''
        :param province_data: DataFrame
        :return: {'nowConfirms':[{"name":"城市名称","value":0},{"name":"城市名称","value":0}]}
        '''
        # 现有确诊
        nowConfirm = province_data.total_confirm - province_data.heal - province_data.dead

        # 现有确诊[{}]
        nowConfirms = list()
        for l in zip(province_data.province_name, nowConfirm):
            sets = dict()
            sets["name"] = l[0]
            sets["value"] = l[1]
            nowConfirms.append(sets)

        # 治愈[{}]
        heals = list()
        for l in zip(province_data.province_name, province_data.heal):
            sets = dict()
            sets["name"] = l[0]
            sets["value"] = l[1]
            heals.append(sets)

        # 死亡[{}]
        deads = list()
        for l in zip(province_data.province_name, province_data.dead):
            sets = dict()
            sets["name"] = l[0]
            sets["value"] = l[1]
            deads.append(sets)

        # 把三组数据合并再字典中
        provinces = dict(nowConfirms=nowConfirms, heals=heals, deads=deads)
        return provinces