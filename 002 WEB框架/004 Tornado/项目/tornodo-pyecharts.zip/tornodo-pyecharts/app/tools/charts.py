'''
charts.py
作用:生成各种图形
'''
#Map是绘制地图的
from pyecharts.charts import Map,Line
#全局配置 标题 自定义颜色  labels
from pyecharts import options as opts
from pyecharts.globals import ThemeType
from pyecharts.globals import ChartType

class Charts(object):
    #中国地图
    def china_map(self,province_name,province_confirm,province_heal,province_dead):
        '''
        :param province_name: 省份的名称
        :param province_confirm: 每个省累计确诊
        :param province_heal: 累计治愈
        :param province_dead: 累计死亡
        :return: china-map.html
        '''
        #现有的确诊人数 Series echarts不认识---->list
        nowConfirm = (province_confirm - province_heal - province_dead).tolist()

        #合成生成器类型提供给地图使用
        gen1 = [list(x) for x in zip(province_name,nowConfirm)]
        gen2 = [list(x) for x in zip(province_name,province_heal)]
        gen3 = [list(x) for x in zip(province_name,province_dead)]

        pieces = [
            {'max': 1, 'color': '#F0F0F9'},
            {'min': 1, 'max': 9, 'color': '#E0E0FF'},
            {'min': 10, 'max': 99, 'color': '#C0C0FE'},
            {'min': 100, 'max': 499, 'color': '#9090FD'},
            {'min': 500, 'max': 999, 'color': '#6060FC'},
            {'min': 1000, 'max': 9999, 'color': '#3030FB'},
            {'min': 10000, 'color': '#0000DD'},
        ]

        '''
        is_roam :不允许放大地图和拖动地图
        is_selected:默认选中
        legend_opts:图例控制对象
            - selected_mode 选中颜色
            - inactive_color 没选中的颜色
        visualmap_opts:控制地图视觉的
            - is_piecewise ：控制色彩
            - pieces:自定义色彩
            - background_color:颜色图例的背景色
            
        chart_id : chinaMap  生成的js变量名称 
            - chart_chinaMap : 定义
            - option_chinaMap ：数据
        '''
        china_map = (
        Map(opts.InitOpts(width='800px',height='600px',chart_id='chinaMap'))
            .add('现有确诊',gen1,'china',is_roam=False,\
                 tooltip_opts=opts.TooltipOpts(background_color='gray',trigger_on='click'),\
                 label_opts=opts.LabelOpts(background_color='gray',color='white'))
            .add('累计治愈',gen2,'china',is_selected=False,is_roam=False,\
                 tooltip_opts=opts.TooltipOpts(background_color='gray',trigger_on='click'),\
                 label_opts=opts.LabelOpts(background_color='gray',color='white'))
            .add('累计死亡', gen3, 'china', is_selected=False,is_roam=False,\
                 tooltip_opts=opts.TooltipOpts(background_color='gray',trigger_on='click'),\
                 label_opts=opts.LabelOpts(background_color='gray',color='white'))
            .set_global_opts(legend_opts=opts.LegendOpts(inactive_color='white'),\
                             title_opts=opts.TitleOpts(title=''),\
                             visualmap_opts=opts.VisualMapOpts(is_piecewise=True,pieces=pieces,background_color='white'))
        )

        '''
        render : 将当前的代码保存成html
        render_notebook : 再jupyter中使用的
        render_embed : 返回html+css+js
        '''
        html = china_map.render_embed()
        return html

    #全国 现有确诊,累计治愈,累计死亡的时间轴变化率
    def china_line(self,create_dt,nowConfirm,heal,dead):
        c = (
            Line(opts.InitOpts(width='550px',height='290px',theme=ThemeType.WONDERLAND,chart_id='chinaLine'))
            .add_xaxis(create_dt)
            .add_yaxis("现有确诊", nowConfirm)
            .add_yaxis("累计治愈", heal)
            .add_yaxis("累计死亡", dead)
            .set_global_opts(title_opts=opts.TitleOpts(title=" "))
        )
        return c.render_embed()


