'''
view_real_time.py
作用:负责建立websocket通信

json:传输的信息是json格式
time:每隔多长事件向客户端发送一次信息
'''
import json,time
from sockjs.tornado import SockJSConnection
from app.tools.getdata import GetData
from app.tools.prodata import ProData
class RealTimeHandler(SockJSConnection):

    #定义一个连接池,使用集合类型，防止用户反复连接
    waiters = set()

    #1.建立连接
    #每一个用户连接当前服务器的时候，都会实例成一个类
    def on_open(self, request):
        try:
            self.waiters.add(self)
        except Exception as e:
            print(e)

    #2.发送消息
    def on_message(self, message):
        try:
            #初始化wbsocket返回的数据
            data = dict()
            g = GetData()
            #广播
            #df中的int64类型可以呗python识别，但是不能呗json识别
            while True:
                data['china_total'] = {k:int(v) for k,v in  g.get_total().loc[0,['confirm','nowConfirm']].to_dict().items()}

                #如果直接返回html,刷新问题,返回js+html+css  大于 数据部分
                # 获取中国地图需要的数据,return DataFrame
                #{con:[{'name':'安徽','value':0},{'name':'江西','value':0}],heals:[],deads:[]}
                data['china_map'] = ProData().pro_province(g.get_province())

                self.broadcast(self.waiters,json.dumps(data))
                time.sleep(20)
        except Exception as e:
            print(e)

    #3.关闭连接
    def on_close(self):
        try:
            self.waiters.remove(self)
        except Exception as e:
            pass

