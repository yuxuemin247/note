'''
view_index.py
作用：返回页面

web.RequestHandler  RESTful
'''
import tornado.web as web
from app.tools.charts import Charts
from app.tools.getdata import GetData

class IndexHandler(web.RequestHandler):
    def get(self):
        #实例化类
        c = Charts()
        g = GetData()

        #获取中国地图需要的数据
        province_data = g.get_province()
        #将数据传递到地图中
        china_map = c.china_map(province_data.province_name.tolist(),\
                                province_data.total_confirm,\
                                province_data.heal,\
                                province_data.dead)

        #获取中国每天变化率线性图
        china_date = g.get_line()
        #数据传递到line
        china_line = c.china_line(china_date.createdt.tolist(),
                                  china_date.nowConfirm.tolist(),
                                  china_date.heal.tolist(),
                                  china_date.dead.tolist())

        #将数据打包成dict传递到html中
        data = dict(
            china_total = g.get_total(),
            china_map = china_map,
            china_line = china_line,
        )

        self.render("index.html",data=data)

