### 需要的模块
- 使用sqlalchemy构建表模型
- 爬虫收集数据
- 使用pandas整理
- 使用DF将数据入库
- 使用tornado配置MVC模型
- 连接和通信
- 获取数据当model层
- 配置图形生成的模块
- 建立二次发送的逻辑

### 结构
- app
    - static 静态部分
    - templates 模板
    - views 控制器
        - view_index.py 首页
        - view_real_tine.py scoket连接
    - tools 工具集
        - charts.py 图形
        - getdata.py 数据库获取数据
    - configs.py 配置
    - urls.py 路由
    - `__init__.py`  框架应用
- manage.py 主要的执行文件
- createmodel.py 创建表
- datasource.py  数据获取(独立项目)