import pandas as pd
import os
from sqlalchemy import create_engine

root_path = os.path.dirname(__file__)
data_path = os.path.join(root_path,'datasets')
conn = create_engine('mysql+pymysql://root:123456@127.0.0.1:3306/nz1904')
for csv in os.listdir(data_path):
    csv_path = os.path.join(data_path,csv)
    df = pd.read_csv(csv_path)
    df.create_dt = pd.to_datetime(df.create_dt)
    table_name = csv.split('.')[0]
    df.to_sql(table_name,conn,index=False,if_exists='append')

