'''
作用:启动文件

netstat -ano | findstr "8000"
taskkill -pid 20324 -f
'''
from app import create_server
if __name__ =='__main__':
    create_server()